#### Code set consists of DataPreprocessing.py, Token_SVM.py, svm_w2v.py

**DataPreprocessing.py**

Used to preprocess the dataset for later training and store the processed training dataset and test dataset into two csv files. 

**Token_SVM.py**

Used to training the datasets in Linear SVM model with default setting. Also add alternative TF-IDF function for training. 

**svm_w2v.py**

Used to transfer the data sets into word2vec and training in linear SVM.